import { Module } from '@nestjs/common';
import { CatfoodController } from './controller/catfood.controller';
import { CatfoodService } from './service/catfood.service';

@Module({
    controllers: [CatfoodController],
    components: [CatfoodService],
})

export class CatfoodModule {}