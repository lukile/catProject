require('ts-node/register');
require('./server');
